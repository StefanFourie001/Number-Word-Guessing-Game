//Stefan Fourie
//41606205
//Creative Project: Guessing games

#include <iostream>
#include<cstdlib>
#include <ctime>
#include <string>
#include<fstream>

using namespace std;

struct credentials // I used this struct function to store the name and surname of the user
{
    string Name;
    string Surname;
    char Choice;
};

void DisplayMenu(string Name , string Surname)// This void function will display the menu of the game as well as the name and surname of the user
{
    credentials c;

    cout<<"**********************"<<endl;
    cout<<"Welcome "<<Name<<" "<<Surname<<"!"<<endl;
    cout<<"1. Play Random Number Guessing Game"<<endl;
    cout<<"2.Play Hang Man"<<endl;
    cout<<"3.Rules"<<endl;
    cout<<"4.Exit game"<<endl;
    cout<<"**********************"<<endl;
}

void GuessGame() //This is the function of the first game
{
    //I declared all my variables I used
    int GameChoice;
    int Guess;
    int winCounter;
    int ranNum;
    int Num;

    Guess=0;
    winCounter=0;
    Num=0;

    //Menu of the game , user must insert the number of the difficulty they have chosen
    cout<<"Welcome to The Guessing Game!"<<endl;
    cout<<"Please choose the difficulty(1.Easy/2.Medium/3.Hard/4.Impossible):";
    cin>>GameChoice;

    //Switch statement is used to to choose the correct settings for the game
    switch(GameChoice)
    {
        case 1:

            ranNum= rand() % 11;
            Num = 10;
            break;

        case 2:
            ranNum= rand() % 26;
            Num = 25;
            break;

        case 3:
            ranNum= rand() % 51;
            Num = 50;
            break;

        case 4:
            ranNum= rand() % 101;
            Num = 100;
            break;
    }

   cout<<"You chose "<<GameChoice<<" difficulty , the number you should guess is between 0 and "<< Num <<endl;
   cout<<"You can start guessing(You only have 10 chances!)"<<endl;

    //Used as counter variable to count how many guesses the user has left
    int count;
    count=0;

    do
    {
        cout<<"Enter your number: ";
        cin>>Guess;
        count++;

        // The following if clauses is to give the user hints if they are too high , low or won the game
        if(Guess < ranNum)
        {
            cout<<"\nToo low , guess again"<<endl;
        }

        else if(Guess > ranNum)
        {
            cout<<"\nToo High , guess again"<<endl;
        }

        else
        {
            cout<<"\nYou won!"<<endl;
            cout<<"It only took you "<< count << " guesses!"<<endl;
        }


    }while(count <= 10 && Guess != ranNum );
}

void hangmandisplay()//Display Menu of hangman
{
    cout<<"=====================/n"<<endl;
    cout<<"Hang Man"<<endl;
    cout<<"=====================/n"<<endl;

    cout<<"Welcome to hang man , save your friend form being hanged by guessing the word"<<endl;
}

void hangmanFail(int misses)//To update the hangman
{
    if(misses == 0)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"==========";
    }

    else if(misses == 1)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<" O   |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"==========";
    }

    else if(misses == 2)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<" O   |\n";
        cout<<" |   |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"==========";
    }

    else if(misses == 3)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<" O   |\n";
        cout<<"/|   |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"==========";
    }

    else if(misses == 4)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<" O   |\n";
        cout<<"/|\\  |\n";
        cout<<"     |\n";
        cout<<"     |\n";
        cout<<"==========";
    }

    else if(misses == 5)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<" O   |\n";
        cout<<"/|\\  |\n";
        cout<<"/    |\n";
        cout<<"     |\n";
        cout<<"==========";
    }

    else if(misses == 6)
    {
        cout<<" +---+\n";
        cout<<" |   |\n";
        cout<<" O   |\n";
        cout<<"/|\\  |\n";
        cout<<"/ \\  |\n";
        cout<<"     |\n";
        cout<<"==========";
    }
}

void hangmanChoices(char arr[50] , string answer)//To save the options in their correct places
{
    cout<<"Incorrect Guesses: "<<endl;
    //for(int i=0 ; i<50 ; i++)
    //{
        //cout<<arr[i]<<" "<<endl;

    //}

    cout<<"\nCorrect Guesses: "<<endl;
    for(int i=0 ; i< answer.length() ; i++)
    {
        cout<<answer[i]<<" ";
    }
}

int textRulesReader(string *pRules)//Saves the text into an array
{
    ifstream infile;
    infile.open("Rules.txt");

    int k=0;


    if(infile.fail())
    {
        cout<<"Can't find file"<<endl;
    }

    else
    {
        while(!(infile.eof()))
    {
        getline(infile , *(pRules+k));
        k++;
    }
    infile.close();
    }
    return k;
}
void displayRules(string *pRules , int *pCount)//Displays the text folder's information
{
    for(int i=0 ; i< *pCount ; i++)
    {
        cout<<(*(pRules + i))<<endl;
    }
}

int main()
{
    srand(time(NULL));//Used srand to make my random numbers more random

    credentials c;//The struct name

    //I used these to make choices and continue the program or not
    int CHOICE;
    char Continue;

    //Used this pointer for the file handling
    const int SIZE =15;
    string Rules[SIZE];
    string *pRules= Rules;
    int count;
    int *pCount = &count;
    *pCount = textRulesReader(pRules);

    //Variables I declared for the Hangman game
    char arrIncorrect[50];
    int incorrect;
    int wordsSize=4;
    string codewords = "Programming";
    string answer = "___________";
    int misses;
    misses = 0;
    bool guess = false;
    char letters;



    //Asked user to enter name + surname
    cout<<"Please enter your Name: ";
    cin>> c.Name ;

    cout<<"\nPlease enter your surname: ";
    cin>> c.Surname;

    DisplayMenu(c.Name , c.Surname);//Menu will be displayed

    cout<<"\nPlease choose a number above: ";//User will be asked to type in the option he/she chooses
    cin>>CHOICE;

    //switch statement is used to choose the correct game via the user's choice

    while(CHOICE !=4 && Continue !='n')// If the user selects 4 from the menu or choose end at the end of each game , the program will end
    {


    switch(CHOICE)//Used switch statements to make sure the user gets the correct game they chose
    {
        case 1:
            GuessGame();

            cout<<"Want to continue the game or close the program?(y\n): ";
            cin>>Continue ;
            break;
        case 2:

            hangmandisplay();

            while(answer != codewords && misses <7)
            {
                hangmanFail(misses);
                hangmanChoices(arrIncorrect , answer);

                cout<<"Enter your guess: ";//Aksed user to enter the guess
                cin>>letters;

                for(int i=0 ; i < codewords.length() ; i++)
                {
                    if(letters == codewords[i])
                    {
                        answer[i]=letters;//If the user guessed the letter correctly , the (_) will chnge into the letter
                        guess=true;
                    }
                }
                if(guess)
                {
                    cout<<"Correct , you're one step closer saving your friend!"<<endl;//When guessed correctly this
                }
                else//when they guess incorrectly , the hangman will update
                {
                    cout<<"Incorrect , come on can't leave your friend hanging like that(Another portion has been added)"<<endl;
                    hangmanFail(misses);
                    misses++;
                }
                guess = false;

                //This if else clause is too say whether the user won or loss
                if(answer==codewords)
                {
                    cout<<"Congratulations , you saved your friend form being hanged!"<<endl;
                }
                else
                {
                    cout<<"Unlucky , maybe next time!"<<endl;
                }

            }
            cout<<"Want to continue the game or close the program?(y\n): ";
            cin>>Continue ;
            break;

        case 3:
                //When user chooses option 3 a text file info will be displayed explaining the rules
                displayRules(pRules , pCount);
                cout<<"Want to continue the game or close the program?(y\n): ";
                cin>>Continue ;
            break;

        case 4://Program will close
            cout<<"Thank you for playing!"<<endl;
            cout<<"Game will be closing in"<<endl;
            break;

        default://default is set to fool proof the game

            while(CHOICE!=1 || CHOICE!=2 || CHOICE!=3 || CHOICE !=4)
            {
                cout<<"Please choose 1 , 2 , 3 or 4 , Please try again: "<<endl;
            }
            break;
    }

    if(Continue =='y')
    {
     DisplayMenu(c.Name , c.Surname);//Menu will be displayed

    cout<<"\nPlease choose a number above: ";//User will be asked to type in the option he/she chooses
    cin>>CHOICE;
    }
    else
    {
        cout<<"Thank you for playing!"<<endl;
        cout<<"Game will be closing in"<<endl;
    }

    }

    return 0;
}
